# Ajanta Storyscapes — The Elephant Who Remembered

A responsive, single-page interactive digital storyboard inspired by the Matri-Poshaka Jataka (Jataka No. 455) and the Ajanta storytelling tradition.

## Run locally
1. Extract the folder.
2. Open `index.html` in a modern browser.

No build step or package installation is required. Google Fonts are optional; a local serif/sans-serif fallback is included.

## Features
- Responsive desktop and mobile layout
- Five illustrated storyboard scenes
- Interactive chapter navigation and reading progress
- Mobile navigation menu
- Historical context, moral themes, preservation note, and team credits
- Reduced-motion preference support

## Story and historical note
This is a contemporary educational adaptation of the Matri-Poshaka Jataka, not a claim that these specific scenes survive as a single Ajanta mural. Ajanta's surviving Buddhist art and the wider Jataka tradition provide the historical and artistic context.
